const NotificationService = require('./service');
module.exports = new NotificationService();
